﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using System.Web;
using UAParser;

namespace middlewary
{
    public class UrlTransfrormerMiddleware
    {
        private RequestDelegate _next;
        public UrlTransfrormerMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public Task Invoke(HttpContext context)
        {
            var ua = context.Request.Headers["user-agent"];
           context.Response.WriteAsync($"<p>User-Agent = {ua} </p>");
           return _next(context);
        }
    }
    public static class UrlTransformerMiddlewareExtensions
    {
        public static IApplicationBuilder useUrlTransformerMiddleware(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<UrlTransfrormerMiddleware>();
        }
    }
}
